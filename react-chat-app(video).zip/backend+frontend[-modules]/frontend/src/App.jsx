import { useEffect, useCallback } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { Loader } from "lucide-react";
import { Toaster } from "react-hot-toast";

import Navbar from "./components/Navbar";
import HomePage from "./pages/HomePage";
import SignupPage from "./pages/SignupPage";
import LoginPage from "./pages/LoginPage";
import SettingPage from "./pages/SettingPage";
import ProfilePage from "./pages/ProfilePage";
import VideoInterface from "./components/VideoInterface";

import { useAuthStore } from "./store/useAuthStore";
import { useTheme } from "./store/useThemeStore";
import { useVideoStore } from "./store/useVideoStore";

function App() {
  const { authUser, checkAuth, isCheckingAuth, socket } = useAuthStore();
  const { theme } = useTheme();
  const { handleIncomingCall, callStatus, handleIceCandidate, endCall, peer } =
    useVideoStore();

    const handleIceCandidateEvent = useCallback(
      ({ candidate, from }) => {
        if (peer && candidate) {
          handleIceCandidate({ candidate, from });
          try {
            peer.addIceCandidate(new RTCIceCandidate(candidate));
          } catch (err) {
            console.error("⚠️ Failed to add ICE candidate:", err);
          }
        }
      },
      [handleIceCandidate, peer]
    );

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  // Memoized function to handle incoming calls
  const handleIncomingCallEvent = useCallback(
    async ({ from, signal }) => {
      // console.log("Incoming call from:", from);
      if (callStatus) return;
      await handleIncomingCall({ from, signal });
    },
    [callStatus, handleIncomingCall]
  );

  useEffect(() => {
    if (!socket) return;

    socket.on("incoming-call", handleIncomingCallEvent);
    socket.on("call-answered", async ({ signal }) => {
      // Fixed event name
      if (peer) {
        try {
          await peer.setRemoteDescription(new RTCSessionDescription(signal));
          // console.log("Call answered by other user Answer: ", signal); // Debugging
        } catch(err)  {
          console.error("⚠️ Failed to set remote description:", err);
        }
      }
    });
    socket.on("ice-candidate", handleIceCandidateEvent); //ice-candidate is used to just send the ice candidate to the other user
    socket.on("call-ended", () => {
      if (callStatus) endCall();
    });

    return () => {
      // Clean up event listeners
      socket.off("incoming-call", handleIncomingCallEvent);
      socket.off("call-answered"); // Fixed event name
      socket.off("ice-candidate", handleIceCandidateEvent);
      socket.off("call-ended");
    };
  }, [
    socket,
    handleIncomingCallEvent,
    handleIceCandidateEvent,
    callStatus,
    endCall,
    peer,
  ]);

  if (isCheckingAuth && !authUser) {
    return (
      <div className="h-screen flex items-center justify-center">
        <Loader className="size-10 animate-spin" />
      </div>
    );
  }

  return (
    <div data-theme={theme}>
      <Navbar />
      <Routes>
        <Route
          path="/"
          element={authUser ? <HomePage /> : <Navigate to="/login" />}
        />
        <Route
          path="/signup"
          element={!authUser ? <SignupPage /> : <Navigate to="/" />}
        />
        <Route
          path="/login"
          element={!authUser ? <LoginPage /> : <Navigate to="/" />}
        />
        <Route path="/settings" element={<SettingPage />} />
        <Route
          path="/profile"
          element={authUser ? <ProfilePage /> : <Navigate to="/login" />}
        />
      </Routes>

      {callStatus && (
        <VideoInterface
          selectedUser={authUser}
          callType={callStatus}
          onClose={() => endCall()}
        />
      )}

      <Toaster />
    </div>
  );
}

export default App;
