import { useState, useEffect, useRef } from "react";
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  PhoneOff,
  Maximize,
  Minimize,
  PhoneIncoming,
} from "lucide-react";
import { useVideoStore } from "../store/useVideoStore";
import { useChatStore } from "../store/useChatStore";

const VideoInterface = ({ callType, onClose }) => {
  const {
    localStream,
    remoteStream,
    callStatus,
    answerCall,
    endCall,
  } = useVideoStore();

  const { selectedUser } = useChatStore();

  const [isFullScreen, setIsFullScreen] = useState(false);
  const [isConnecting, setIsConnecting] = useState(true); // Always start as connecting
  const [isIncoming, setIsIncoming] = useState(callType === "incoming");

  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);

  // Handle local stream
  useEffect(() => {
    if (localStream && localVideoRef.current) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  // Handle remote stream and connection state
  useEffect(() => {
    if (remoteStream && remoteVideoRef.current) {
      remoteVideoRef.current.srcObject = remoteStream;
      setIsConnecting(false); // Connection established when remote stream is available
    }
  }, [remoteStream]);

  // Remove the automatic timeout for outgoing calls
  // We'll now rely on remote stream presence to determine connection state

  const handleAcceptCall = async () => {
    try {
      await answerCall();
      setIsIncoming(false); // No longer an incoming call after accepting
      console.log("Successfully answered call");
    } catch (error) {
      console.error("Error answering call:", error);
    }
  };

  const handleEndCall = () => {
    endCall();
    onClose();
  };

  const toggleAudio = () => {
    if (localStream) {
      const audioTrack = localStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
      }
    }
  };

  const toggleVideo = () => {
    if (localStream) {
      const videoTrack = localStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
      }
    }
  };

  const getCallStatusText = () => {
    if (isIncoming && isConnecting) {
      return "Connecting";
    }
    if (callType === "outgoing" && isConnecting) {
      return "Calling";
    }
    return "Connected";
  };

  // Incoming Call UI - only show if it's an incoming call and still connecting
  if (isIncoming && isConnecting) {
    return (
      <div className="fixed inset-0 bg-base-300/90 z-50 flex items-center justify-center">
        <div className="bg-base-100 p-6 rounded-lg shadow-lg flex flex-col items-center text-center">
          <PhoneIncoming size={48} className="text-primary" />
          <p className="text-lg font-semibold mt-4">
            Incoming call from {selectedUser?.fullName || "User"}
          </p>
          <div className="flex gap-4 mt-6">
            <button onClick={handleAcceptCall} className="btn btn-success">
              Accept
            </button>
            <button onClick={handleEndCall} className="btn btn-error">
              Reject
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-base-300/90 z-50">
      <div className="relative h-full flex items-center justify-center">
        <div
          className={`relative rounded-lg overflow-hidden flex flex-col shadow-lg border border-base-200 
          ${isFullScreen ? "w-screen h-screen" : "w-[800px] h-[600px]"}`}
        >
          <div className="flex-1 grid grid-cols-2 gap-4 p-4 bg-base-200">
            <div className="col-span-2 bg-base-100 rounded-lg flex items-center justify-center relative">
              {!remoteStream || isConnecting ? (
                <div className="flex flex-col items-center gap-4">
                  <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                  <p className="text-primary text-lg font-semibold">
                    {getCallStatusText()} {selectedUser?.fullName || "User"}...
                  </p>
                </div>
              ) : (
                <video 
                  ref={remoteVideoRef} 
                  autoPlay 
                  className="w-full h-full object-cover" 
                />
              )}
            </div>

            {/* Local stream - only show if we have a local stream */}
            {localStream && (
              <div className="absolute bottom-24 right-4 w-48 h-36 bg-base-100 rounded-lg border border-base-300 flex items-center justify-center m-5">
                <video 
                  ref={localVideoRef} 
                  autoPlay 
                  muted 
                  className="w-full h-full object-cover rounded-lg" 
                />
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="h-20 bg-base-100 flex items-center justify-center gap-4 px-4 border-t border-base-300">
            <button
              onClick={toggleAudio}
              className={`btn btn-circle transition-all ${
                !localStream?.getAudioTracks()[0]?.enabled ? "btn-error" : "btn-primary"
              }`}
            >
              {localStream?.getAudioTracks()[0]?.enabled ? <Mic /> : <MicOff />}
            </button>

            <button
              onClick={toggleVideo}
              className={`btn btn-circle transition-all ${
                !localStream?.getVideoTracks()[0]?.enabled ? "btn-error" : "btn-primary"
              }`}
            >
              {localStream?.getVideoTracks()[0]?.enabled ? <Video /> : <VideoOff />}
            </button>

            <button onClick={handleEndCall} className="btn btn-circle btn-error">
              <PhoneOff />
            </button>

            <button
              onClick={() => setIsFullScreen(!isFullScreen)}
              className="btn btn-circle btn-primary"
            >
              {isFullScreen ? <Minimize /> : <Maximize />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoInterface;