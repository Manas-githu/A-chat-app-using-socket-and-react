import { create } from "zustand";
import { useAuthStore } from "./useAuthStore";
import toast from "react-hot-toast";
import { useChatStore } from "./useChatStore";

const ICE_SERVERS = {
  iceServers: [
    {
      urls: [
        "stun:stun.l.google.com:19302",
        "stun:stun1.l.google.com:19302",
      ],
    },
  ],
  iceCandidatePoolSize: 10,
};

export const useVideoStore = create((set, get) => ({
  localStream: null,
  remoteStream: null,
  callStatus: null, // 'incoming' | 'outgoing' | 'connected' | null
  peer: null,
  incomingCall: null,
  iceCandidatesQueue: [],

  initializeMedia: async () => {
    if (get().localStream) return get().localStream;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      set({ localStream: stream });
      console.log("Local stream initialized successfully");
      return stream;
    } catch (error) {
      toast.error("Cannot access camera/microphone. Please check permissions.");
      console.error("Media access error:", error);
      throw error;
    }
  },

  makeCall: async (userId) => {
    try {
      const stream = await get().initializeMedia();
      const socket = useAuthStore.getState().socket;
      const currentUser = useAuthStore.getState().authUser;

      const peer = new RTCPeerConnection(ICE_SERVERS);
      const remoteStream = new MediaStream(); // Creating a new remote stream
      set({ remoteStream });
      console.log("made a call and set remote stream null for now");  

      stream.getTracks().forEach((track) => peer.addTrack(track, stream));

      peer.onicecandidate = (event) => {
        if (event.candidate) {
          socket.emit("ice-candidate", {
            candidate: event.candidate,
            to: userId,
          });
        }
      };

      peer.ontrack = (event) => {
        event.streams[0].getTracks().forEach((track) => {
          
            remoteStream.addTrack(track);
          
        });
        set({ remoteStream });
        console.log("remote stream added to remote stream");
      };

      peer.onconnectionstatechange = () => {
        if (peer.connectionState === "disconnected") {
          setTimeout(() => {
            if (peer.connectionState === "disconnected") {
              get().endCall();
            }
          }, 3000);
        }
      };

      const offer = await peer.createOffer();
      await peer.setLocalDescription(offer);
      console.log("call made and local description set: ", offer);
      socket.emit("call-user", {
        to: userId,
        from: currentUser._id,
        signal: offer,
      });

      set({ peer, callStatus: "outgoing" });
    } catch (error) {
      toast.error("Failed to start call");
      console.error("Call initiation error:", error);
      get().endCall();
    }
  },
  handleIceCandidate: async ({ candidate }) => {
    const { peer } = get();
    try {
      if (peer?.remoteDescription) {
        await peer.addIceCandidate(new RTCIceCandidate(candidate));
      } else {
        set((state) => ({
          iceCandidatesQueue: [...state.iceCandidatesQueue, candidate],
        }));
      }
    } catch (error) {
      console.error("Error handling ICE candidate:", error);
    }
  },
  
    
    handleIncomingCall: async ({ from, signal }) => {
      try {
        set({
          incomingCall: { from, signal },
          callStatus: "incoming",
        });
  
        const peer = new RTCPeerConnection(ICE_SERVERS);
        await peer.setRemoteDescription(new RTCSessionDescription(signal));
        set({ peer });
        console.log("remote description set");
  
        const { iceCandidatesQueue } = get();
        if (iceCandidatesQueue.length > 0) {
          for (const candidate of iceCandidatesQueue) {
            await peer.addIceCandidate(new RTCIceCandidate(candidate));
          }
          console.log("ice candidates added");
          set({ iceCandidatesQueue: [] });
        }
        await get().answerCall();
      } catch (error) {
        console.error("Error handling incoming call:", error);
        get().endCall();
      }
    },

  answerCall: async () => {
    try {
      const { incomingCall, iceCandidatesQueue } = get();
      if (!incomingCall) return;

      const stream = await get().initializeMedia();
      const socket = useAuthStore.getState().socket;
      const peer = new RTCPeerConnection(ICE_SERVERS);
      const remoteStream = new MediaStream(); // Creating a new remote stream

      
      stream.getTracks().forEach((track) => peer.addTrack(track, stream));
      
      set({ localStream: stream, remoteStream });
      peer.onicecandidate = (event) => {
        if (event.candidate) {
          socket.emit("ice-candidate", {
            candidate: event.candidate,
            to: incomingCall.from,
          });
        }
      };

      peer.ontrack = (event) => {
        event.streams[0].getTracks().forEach((track) => {
          remoteStream.addTrack(track);
        });
        set({ remoteStream });
      };

      // Process queued ICE candidates
      if (iceCandidatesQueue.length > 0) {
        for (const candidate of iceCandidatesQueue) {
          await peer.addIceCandidate(new RTCIceCandidate(candidate));
        }
        set({ iceCandidatesQueue: [] });
      }

      await peer.setRemoteDescription(new RTCSessionDescription(incomingCall.signal));
      const answer = await peer.createAnswer();
      await peer.setLocalDescription(answer);
      
      set({ peer, callStatus: "connected" });

      socket.emit("answer-call", {
        to: incomingCall.from,
        signal: answer,
      });


    } catch (error) {
      console.error("Error answering call:", error);
      get().endCall();
    }
  },

  endCall: () => {
    const { peer, localStream, remoteStream } = get();
    const socket = useAuthStore.getState().socket;
    const { selectedUser } = useChatStore.getState();

    if (peer) peer.close();
    if (localStream) localStream.getTracks().forEach((track) => track.stop());
    if (remoteStream) remoteStream.getTracks().forEach((track) => track.stop());

    set({
      peer: null,
      localStream: null,
      remoteStream: null,
      callStatus: null,
      incomingCall: null,
      iceCandidatesQueue: [],
    });

    socket.emit("end-call", { to: selectedUser._id });
  },
}));
